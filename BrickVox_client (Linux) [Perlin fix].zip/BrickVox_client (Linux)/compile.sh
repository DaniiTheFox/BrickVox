g++ -g main.cpp -lGLU -lglut -lGL `sdl2-config --cflags --libs` -lSDL2_mixer -lcurl -L/usr/include/mysql -lmysqlclient -I/usr/include/mysql -pthread -lSDL2main -lSDL2 -lcurl
